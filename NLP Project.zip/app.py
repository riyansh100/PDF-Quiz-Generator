# app.py
import os
import tempfile
import pdfplumber
import docx
import streamlit as st
from fpdf import FPDF
import google.generativeai as genai
import re

# -------------------------------
# Configure Google API
# -------------------------------
os.environ["GOOGLE_API_KEY"] = "AIzaSyAGIbWNUwSPoYu6v7bPl0IvV6PfZdPFWcE"
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
model = genai.GenerativeModel("gemini-2.0-flash")

# -------------------------------
# Helper functions
# -------------------------------
def extract_text_from_file(file):
    filename = file.name
    ext = filename.rsplit('.', 1)[1].lower()
    text = ""
    if ext == "pdf":
        with pdfplumber.open(file) as pdf:
            text = ''.join([page.extract_text() or '' for page in pdf.pages])
    elif ext == "docx":
        doc = docx.Document(file)
        text = ' '.join([para.text for para in doc.paragraphs])
    elif ext == "txt":
        text = file.read().decode("utf-8")
    return text

def generate_mcqs(input_text, num_questions):
    prompt = f"""
Generate {num_questions} MCQs from the following text:

{input_text}

Format:
## MCQ
Question: [question]
A) [option A]
B) [option B]
C) [option C]
D) [option D]
Correct Answer: [correct option]
"""
    response = model.generate_content(prompt)
    return response.text.strip()

def parse_mcqs(mcqs_text):
    mcqs_list = []
    mcq_blocks = re.split(r'## MCQ', mcqs_text)
    for mcq in mcq_blocks:
        mcq = mcq.strip()
        if not mcq:
            continue
        try:
            question_match = re.search(r'Question:\s*(.*)', mcq)
            question_text = question_match.group(1).strip() if question_match else "Question text missing"

            options = {}
            for opt in ['A', 'B', 'C', 'D']:
                pattern = rf'{opt}\)\s*(.*?)(?=(?:[A-D]\)|Correct Answer:))'
                match = re.search(pattern, mcq, re.DOTALL)
                options[opt] = match.group(1).strip() if match else f"Option {opt} missing"

            answer_match = re.search(r'Correct Answer:\s*([A-D])', mcq)
            correct_answer = answer_match.group(1).strip() if answer_match else 'A'

            mcqs_list.append({
                "question": question_text,
                "options": options,
                "answer": correct_answer
            })
        except Exception:
            continue
    return mcqs_list

def save_txt(mcqs):
    tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".txt")
    with open(tmp_file.name, "w", encoding="utf-8") as f:
        f.write(mcqs)
    return tmp_file.name

def save_pdf(mcqs):
    tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    for mcq in mcqs.split("## MCQ"):
        if mcq.strip():
            pdf.multi_cell(0, 10, mcq.strip())
            pdf.ln(5)
    pdf.output(tmp_file.name)
    return tmp_file.name

# -------------------------------
# Streamlit UI
# -------------------------------
st.set_page_config(page_title="Interactive MCQ Generator", page_icon="📝", layout="wide")
st.title("📝 Interactive AI-Powered MCQ Generator")
st.markdown(
    "Upload a document and generate multiple-choice questions (MCQs) to test your knowledge. "
    "You can also submit your answers and download them as TXT or PDF."
)

with st.expander("📄 Upload & Settings", expanded=True):
    uploaded_file = st.file_uploader("Choose a file", type=["pdf", "docx", "txt"])
    num_questions = st.number_input(
        "Number of MCQs to generate", min_value=1, max_value=50, value=5, step=1
    )
    generate_btn = st.button("Generate MCQs")

# Initialize session state
if "mcqs_list" not in st.session_state:
    st.session_state.mcqs_list = None
if "user_answers" not in st.session_state:
    st.session_state.user_answers = {}
if "mcqs_text" not in st.session_state:
    st.session_state.mcqs_text = ""

# Generate MCQs
if generate_btn and uploaded_file:
    text = extract_text_from_file(uploaded_file)
    if not text.strip():
        st.error("No text could be extracted from this file.")
    else:
        mcqs_text = generate_mcqs(text, num_questions)
        st.session_state.mcqs_list = parse_mcqs(mcqs_text)
        st.session_state.mcqs_text = mcqs_text
        st.session_state.user_answers = {}
        st.success("✅ MCQs generated successfully!")

# Display MCQs
if st.session_state.mcqs_list:
    st.subheader("📝 Answer the following MCQs:")
    for idx, mcq in enumerate(st.session_state.mcqs_list):
        st.markdown(f"**Q{idx+1}: {mcq['question']}**")
        st.session_state.user_answers[idx] = st.radio(
            label=f"Select an option for Q{idx+1}",
            options=['A','B','C','D'],
            format_func=lambda x, opts=mcq['options']: f"{x}) {opts[x]}",
            key=f"q{idx}"
        )

    st.markdown("---")
    if st.button("Submit Answers"):
        score = 0
        st.subheader("📊 Results:")
        for idx, mcq in enumerate(st.session_state.mcqs_list):
            user_ans = st.session_state.user_answers.get(idx)
            correct_ans = mcq['answer']
            if user_ans == correct_ans:
                st.success(f"✅ Q{idx+1}: Correct ({user_ans})")
                score += 1
            else:
                st.error(f"❌ Q{idx+1}: Incorrect (Your: {user_ans} | Correct: {correct_ans})")
        st.info(f"**Your Score: {score}/{len(st.session_state.mcqs_list)}**")

        col1, col2 = st.columns(2)
        txt_path = save_txt(st.session_state.mcqs_text)
        pdf_path = save_pdf(st.session_state.mcqs_text)
        with col1:
            st.download_button("📄 Download MCQs as TXT", data=open(txt_path, "rb"), file_name="mcqs.txt")
        with col2:
            st.download_button("📕 Download MCQs as PDF", data=open(pdf_path, "rb"), file_name="mcqs.pdf")
